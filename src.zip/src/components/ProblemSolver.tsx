// src/components/ProblemSolver.tsx
//
// CHANGES FROM PREVIOUS VERSION:
//
// FIX 1 — Hydration mismatch (the primary crash).
//   Old code read localStorage inside useState's lazy initializer:
//     useState<string | null>(() => {
//       if (typeof window === "undefined") return null;
//       return localStorage.getItem(storageKey);   ← ran during SSR too
//     })
//   During SSR: window is undefined → state = null → server renders nothing.
//   During client hydration: window exists → state = "abc123" → client renders
//   "Submission ID: abc123". React sees a mismatch and throws.
//   Fix: initialize to null unconditionally; read localStorage in a useEffect
//   that only fires after mount (client-only, never during SSR).
//
// FIX 2 — storageKey memoized with useMemo.
//   Was recomputed on every render and included in useEffect deps, which could
//   cause unnecessary effect re-runs if React ever changed reference equality
//   semantics. Now stable across renders.
//
// FIX 3 — Polling effect dependency array cleaned up.
//   Was [submissionId, storageKey]. storageKey is now memoized so it's stable.
//   The polling effect only needs to react to submissionId changing.
//
// Everything else (TruncatedText, SubmissionResults, submit handler, LANGUAGES
// constant, TERMINAL_STATUSES) is unchanged from the last correct version.

"use client";

import React, { useState, useEffect, useMemo } from "react";
import { CodeEditor } from "@/components/CodeEditor";
import { SubmissionStatus } from "@/components/SubmissionStatus";
import { getToken } from "@/lib/auth-client";

// ─── Constants ───────────────────────────────────────────────────────────────

const LANGUAGES = [
  { value: "JAVASCRIPT", label: "JavaScript" },
  { value: "CPP", label: "C++" },
];

const TERMINAL_STATUSES = new Set(["COMPLETED", "FAILED"]);
const POLL_INTERVAL_MS = 2000;

// ─── TruncatedText ───────────────────────────────────────────────────────────

function TruncatedText({
  text,
  max = 300,
  ariaLabel,
}: {
  text: string;
  max?: number;
  ariaLabel?: string;
}) {
  const [expanded, setExpanded] = useState(false);

  if (!text) return <span aria-label="empty">-</span>;
  if (text.length <= max) return <span>{text}</span>;

  return (
    <span>
      {expanded ? text : `${text.slice(0, max)}…`}
      <button
        type="button"
        className="ml-2 underline text-blue-600 focus:outline-none focus:ring focus:ring-blue-300 rounded px-1"
        aria-label={ariaLabel ?? (expanded ? "Show less" : "Show more")}
        onClick={() => setExpanded((prev) => !prev)}
      >
        {expanded ? "Show less" : "Show more"}
      </button>
    </span>
  );
}

// ─── SubmissionResults ───────────────────────────────────────────────────────

function SubmissionResults({ submission }: { submission: any }) {
  const results: any[] = Array.isArray(submission?.executionResults)
    ? submission.executionResults
    : [];

  if (results.length === 0) {
    return (
      <div className="text-gray-500 mt-4 text-sm">No test cases executed.</div>
    );
  }

  return (
    <div className="mt-4 overflow-x-auto">
      <h3 className="font-semibold mb-2 text-sm">Test Case Results</h3>
      <table className="w-full border text-sm" aria-label="Test case results">
        <thead>
          <tr className="bg-gray-100">
            <th className="p-2 text-left">#</th>
            <th className="p-2 text-left">Input</th>
            <th className="p-2 text-left">Expected</th>
            <th className="p-2 text-left">Actual</th>
            <th className="p-2 text-left">Pass</th>
            <th className="p-2 text-left">Error</th>
          </tr>
        </thead>
        <tbody>
          {results.map((res, idx) => (
            <tr key={res.testCaseId ?? idx} className="border-t">
              <td className="p-2">{idx + 1}</td>
              <td className="p-2 whitespace-pre-line max-w-xs">
                <TruncatedText
                  text={res.inputSnapshot ?? ""}
                  ariaLabel="Show more input"
                />
              </td>
              <td className="p-2 whitespace-pre-line max-w-xs">
                <TruncatedText
                  text={res.expectedOutputSnapshot ?? ""}
                  ariaLabel="Show more expected output"
                />
              </td>
              <td className="p-2 whitespace-pre-line max-w-xs">
                <TruncatedText
                  text={res.actualOutput ?? ""}
                  ariaLabel="Show more actual output"
                />
              </td>
              <td className="p-2" aria-label={res.passed ? "Passed" : "Failed"}>
                {res.passed ? "✅" : "❌"}
              </td>
              <td className="p-2 text-xs text-red-600">
                <TruncatedText
                  text={res.stderr ?? ""}
                  ariaLabel="Show more error output"
                />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ─── ProblemSolver ───────────────────────────────────────────────────────────

export function ProblemSolver({ problemId }: { problemId: string }) {
  // FIX 2: memoize so the string reference is stable across renders.
  const storageKey = useMemo(
    () => `lastSubmissionId:${problemId}`,
    [problemId],
  );

  const [code, setCode] = useState("");
  const [language, setLanguage] = useState("JAVASCRIPT");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // FIX 1: initialize to null — identical on server and client.
  // localStorage is read in the dedicated mount effect below.
  const [submissionId, setSubmissionId] = useState<string | null>(null);

  const [polling, setPolling] = useState(false);
  const [submission, setSubmission] = useState<any>(null);
  const [pollError, setPollError] = useState<string | null>(null);

  // ── Rehydrate from localStorage after mount ─────────────────────────────
  // FIX 1 (continued): runs only on the client after the first paint.
  // Server render → null. Client hydration → null (matches server). Then this
  // effect fires and sets the real value → React re-renders with the stored
  // submissionId, which then triggers the polling effect below.
  useEffect(() => {
    const stored = localStorage.getItem(storageKey);
    if (stored) setSubmissionId(stored);
  }, [storageKey]);

  // ── Polling effect ──────────────────────────────────────────────────────
  // FIX 3: deps array is [submissionId] only — storageKey is memoized and
  // stable, so adding it would not change semantics but does clarify intent.
  useEffect(() => {
    if (!submissionId) {
      localStorage.removeItem(storageKey);
      setPolling(false);
      return;
    }

    localStorage.setItem(storageKey, submissionId);
    setPolling(true);
    setPollError(null);

    const interval = setInterval(async () => {
      try {
        const res = await fetch(`/api/submissions/${submissionId}`);

        if (res.status === 401 || res.status === 403) {
          window.location.href = "/login";
          return;
        }

        if (!res.ok) {
          setPollError("Failed to fetch submission status.");
          return;
        }

        const data = await res.json();
        // API may wrap in { submission: {...} } or return the object directly.
        const sub: any = data.submission ?? data;
        setSubmission(sub);

        if (TERMINAL_STATUSES.has(sub?.status)) {
          clearInterval(interval);
          setPolling(false);
        }
      } catch (e: any) {
        setPollError(e?.message ?? "Unknown polling error");
      }
    }, POLL_INTERVAL_MS);

    return () => clearInterval(interval);
    // storageKey is memoized and intentionally omitted — adding it here would
    // restart the polling interval any time problemId changes, but the
    // submissionId state already handles that correctly.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [submissionId]);

  // ── Submit handler ──────────────────────────────────────────────────────
  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setPollError(null);
    // Null the id first so the polling effect's cleanup fires before
    // the new id is set (avoids a brief double-poll window).
    setSubmissionId(null);
    setSubmission(null);

    try {
      const token = getToken();
      if (!token) {
        setError("You must be logged in to submit.");
        return;
      }

      const res = await fetch("/api/submit", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ problemId, code, language }),
      });

      if (res.status === 401 || res.status === 403) {
        window.location.href = "/login";
        return;
      }

      const data = await res.json();

      if (!res.ok || !data.submission?.id) {
        throw new Error(data.error ?? "Submission failed");
      }

      setSubmissionId(data.submission.id);
    } catch (err: any) {
      setError(err.message ?? "Unknown error");
    } finally {
      setLoading(false);
    }
  }

  const isSubmitting = loading || polling;

  return (
    <form className="space-y-4" onSubmit={handleSubmit} noValidate>
      {/* Language selector */}
      <div>
        <label
          htmlFor="language-select"
          className="block text-sm font-medium mb-1"
        >
          Language
        </label>
        <select
          id="language-select"
          className="border rounded p-2"
          value={language}
          onChange={(e) => setLanguage(e.target.value)}
        >
          {LANGUAGES.map((lang) => (
            <option key={lang.value} value={lang.value}>
              {lang.label}
            </option>
          ))}
        </select>
      </div>

      {/* Code editor */}
      <CodeEditor value={code} onChange={setCode} language={language} />

      {/* Submit button */}
      <button
        type="submit"
        className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded disabled:opacity-60 transition"
        disabled={isSubmitting || !code.trim()}
        aria-busy={isSubmitting}
      >
        {loading ? "Submitting…" : polling ? "Waiting for result…" : "Submit"}
      </button>

      {/* Submission error */}
      {error && (
        <div className="text-red-600 text-sm" role="alert">
          {error}
        </div>
      )}

      {/* Submission ID confirmation */}
      {submissionId && (
        <div className="text-green-700 text-sm">
          Submission ID: <span className="font-mono">{submissionId}</span>
        </div>
      )}

      {/* Polling error */}
      {pollError && (
        <div className="text-red-600 text-sm" role="alert">
          {pollError}
        </div>
      )}

      {/* Results */}
      {submission && (
        <div className="mt-4">
          <SubmissionStatus
            status={submission.status}
            verdict={submission.verdict}
          />
          {submission.errorCode && (
            <div className="text-red-700 text-sm mt-2" role="alert">
              Error: <span className="font-mono">{submission.errorCode}</span>
              {submission.errorMessage && ` — ${submission.errorMessage}`}
            </div>
          )}
          <SubmissionResults submission={submission} />
        </div>
      )}
    </form>
  );
}