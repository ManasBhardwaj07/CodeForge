import { prisma } from "@/lib/prisma";

export async function getSubmissionById(id: string) {
  const submission = await prisma.submission.findUnique({
    where: { id },
    include: {
      executionResults: {
        orderBy: { createdAt: "asc" },
        select: {
          id: true,
          testCaseId: true,
          inputSnapshot: true,
          expectedOutputSnapshot: true,
          actualOutput: true,
          stderr: true,
          passed: true,
        },
      },
    },
  });
  return submission;
}

export async function listSubmissionsForUser(userId: string) {
  return prisma.submission.findMany({
    where: { userId },
    orderBy: { createdAt: "desc" },
    select: {
      id: true,
      verdict: true,
      createdAt: true,
      problem: {
        select: { title: true },
      },
    },
  });
}