// src/app/api/submissions/[id]/route.ts
//
// REASON THIS FILE WAS MISSING: Was never created.
// IMPACT: ProblemSolver.tsx polls this endpoint every 2 seconds after a submit.
// Every poll returned 404, so submission status and test-case results never
// appeared in the UI and the polling loop ran forever.
//
// WHAT THIS DOES:
//   GET /api/submissions/:id
//   • Requires a valid Bearer token (401/403 if missing or invalid).
//   • Returns the submission only if it belongs to the requesting user.
//     This prevents users from reading each other's submissions.
//   • Response shape expected by ProblemSolver.tsx:
//       {
//         id, status, verdict, errorCode?, errorMessage?,
//         executionResults: [
//           { testCaseId, inputSnapshot, expectedOutputSnapshot,
//             actualOutput, stderr, passed }
//         ]
//       }
//
// SERVICE DEPENDENCY:
//   Assumes submission.service exports:
//     getSubmissionById(id: string): Promise<Submission | null>
//
//   If it doesn't yet, add it — the query is a simple findUnique/findFirst
//   by primary key, with `include: { executionResults: true }`.

import { AuthorizationError, requireAuth } from "@/lib/auth";
import { errorResponse } from "@/lib/http";
import { getSubmissionById } from "@/services/submission.service";

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  // ── Auth ─────────────────────────────────────────────────────────────────
  let user: Awaited<ReturnType<typeof requireAuth>>;
  try {
    user = await requireAuth(request);
  } catch (error) {
    if (error instanceof AuthorizationError) {
      if (error instanceof Error) {
        return errorResponse(error.message, (error as any).code, (error as any).statusCode);
      }
      return errorResponse("Unknown error", "UNKNOWN", 500);
    }
    return errorResponse("Internal server error", "INTERNAL_SERVER_ERROR", 500);
  }

  // ── Params ────────────────────────────────────────────────────────────────
  // Next.js 15: params is a Promise. Next.js 14: awaiting a plain object is a no-op.
  const { id } = await params;

  if (!id || typeof id !== "string") {
    return errorResponse("Invalid submission ID", "INVALID_ID", 400);
  }

  // ── Fetch ─────────────────────────────────────────────────────────────────
  try {
    const submission = await getSubmissionById(id);

    if (!submission) {
      return errorResponse("Submission not found", "SUBMISSION_NOT_FOUND", 404);
    }

    // Ownership check — users may only read their own submissions.
    // Remove this block if your platform intentionally allows public viewing.
    if (submission.userId !== user.userId) {
      return errorResponse("Forbidden", "FORBIDDEN", 403);
    }

    return Response.json(submission, { status: 200 });
  } catch (error) {
    if (error instanceof Error) {
      return errorResponse(error.message, (error as any).code ?? "INTERNAL_SERVER_ERROR", (error as any).statusCode ?? 500);
    }
    return errorResponse("Internal server error", "INTERNAL_SERVER_ERROR", 500);
  }
}