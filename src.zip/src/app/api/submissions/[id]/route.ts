// src/app/api/submissions/[id]/route.ts
//
// This file was moved from src/app/submissions/[id]/route.ts to the correct API route location.
// See comments in the file for details.

import { AuthorizationError, requireAuth } from "@/lib/auth";
import { errorResponse } from "@/lib/http";
import { getSubmissionById } from "@/services/submission.service";

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  let user: Awaited<ReturnType<typeof requireAuth>>;
  try {
    user = await requireAuth(request);
  } catch (error) {
    if (error instanceof AuthorizationError) {
      if (error instanceof Error) {
        return errorResponse(error.message, (error as any).code, (error as any).statusCode);
      }
      return errorResponse("Unknown error", "UNKNOWN", 500);
    }
    return errorResponse("Internal server error", "INTERNAL_SERVER_ERROR", 500);
  }

  const { id } = await params;

  if (!id || typeof id !== "string") {
    return errorResponse("Invalid submission ID", "INVALID_ID", 400);
  }

  try {
    const submission = await getSubmissionById(id);

    if (!submission) {
      return errorResponse("Submission not found", "SUBMISSION_NOT_FOUND", 404);
    }

    if (submission.userId !== user.userId) {
      return errorResponse("Forbidden", "FORBIDDEN", 403);
    }

    return Response.json(submission, { status: 200 });
  } catch (error) {
    if (error instanceof Error) {
      return errorResponse(error.message, (error as any).code ?? "INTERNAL_SERVER_ERROR", (error as any).statusCode ?? 500);
    }
    return errorResponse("Internal server error", "INTERNAL_SERVER_ERROR", 500);
  }
}
